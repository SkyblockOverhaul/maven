package net.sbo.guilib.fabric

import net.sbo.guilib.core.FrameStats
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.gui.screens.Screen
import net.minecraft.client.input.CharacterEvent
import net.minecraft.client.input.KeyEvent
import net.minecraft.client.input.MouseButtonEvent
import net.minecraft.network.chat.ClickEvent
import net.minecraft.network.chat.Component
import net.minecraft.network.chat.HoverEvent
import net.minecraft.world.item.ItemStack
import net.sbo.guilib.core.UiRoot
import net.sbo.guilib.core.dom.VNode
import net.sbo.guilib.core.dom.VProvider
import net.sbo.guilib.fabric.font.FontManager
import net.sbo.guilib.fabric.input.Cursors
import net.sbo.guilib.fabric.input.Keys
import net.sbo.guilib.fabric.render.CommandRenderer
import net.sbo.guilib.core.dom.VComponent
import net.sbo.guilib.fabric.debug.MetricsOverlay
import net.sbo.guilib.fabric.resources.Stylesheets

/**
 * A Minecraft [Screen] hosting a GuiLib UI. Usually created through [GuiLib.open].
 *
 * @param content the root node, e.g. `VComponent(App, Unit, null)` (see [GuiLib.open] for the convenient forms)
 * @param stylesheets resource locations like `"mymod:ui/main.css"` (loaded from `assets/mymod/ui/main.css`)
 * @param scale the screen's own GUI scale (physical pixels per CSS px, fractions allowed), or `null` for Minecraft's;
 *   changeable later with `useScreenScale()` / `root.document.scale`
 * @param blurBackground `false` = no blur behind the screen (the dark overlay stays); changeable later with
 *   `useBackgroundBlur()` / `root.document.backgroundBlur`
 * @param metrics show the metrics overlay (frame time, CPU, memory, leak check) from the start; Ctrl + F12 toggles it
 *   in every GuiLib screen, see [showMetrics]
 */
open class GuiLibScreen(
    title: Component,
    private val content: VNode,
    private val stylesheets: List<String> = emptyList(),
    /** Draw Minecraft's default blurred/dimmed background behind the UI. */
    private val vanillaBackground: Boolean = true,
    private val pauseGame: Boolean = false,
    scale: Float? = null,
    blurBackground: Boolean = true,
    metrics: Boolean = false,
) : Screen(title) {

    val root: UiRoot = UiRoot(FontManager, Stylesheets.loadAll(stylesheets))
    private var mounted = false

    init {
        root.document.scale = scale
        root.document.backgroundBlur = blurBackground
        GuiLib.initDocument(root)
        Stylesheets.watch(this)
    }

    /** Reloads all stylesheets (used by hot reload and `/guilib reload`). */
    fun reloadStylesheets() {
        root.document.setStylesheets(Stylesheets.loadAll(stylesheets))
    }

    /** The translator the UI was last rendered with; a new one (language change, resource reload) re-renders. */
    private var translator: Translator? = null

    override fun init() {
        if (!mounted) {
            renderContent()
            mounted = true
        }
    }

    /** Whether the metrics overlay is shown (Ctrl + F12 toggles it, unless [METRICS_SHORTCUT] is off). */
    var showMetrics: Boolean = metrics
        set(value) {
            if (field != value) {
                field = value
                if (mounted) syncMetrics()
            }
        }

    /**
     * The metrics overlay: its own document (ua.css only, Minecraft's GUI scale), drawn over this screen's and left out
     * of [FrameStats], so it neither shows up in its own numbers nor gets styled by the screen's CSS.
     */
    private var metricsRoot: UiRoot? = null

    /** True while a press that started on the overlay is held: the release belongs to it too. */
    private var metricsPressed = false

    private fun syncMetrics() {
        val show = showMetrics && mounted
        if (show && metricsRoot == null) {
            val r = UiRoot(FontManager, Stylesheets.loadAll(emptyList()))
            GuiLib.initDocument(r)
            FrameStats.uncounted { r.render(VComponent(MetricsOverlay.Window, MetricsOverlay.Props(root.document) { showMetrics = false }, null)) }
            metricsRoot = r
        } else if (!show && metricsRoot != null) {
            metricsRoot?.document?.unmount()
            metricsRoot = null
            metricsPressed = false
        }
    }

    /** True if Minecraft GUI position ([x], [y]) is on the overlay window. */
    private fun onMetrics(x: Double, y: Double): Boolean {
        val r = metricsRoot ?: return false
        val box = r.document.body.querySelector(".guilib-metrics")?.getBoundingClientRect() ?: return false
        return x >= box.x && y >= box.y && x < box.x + box.width && y < box.y + box.height
    }

    private fun renderContent() {
        val t = Translator.current()
        translator = t
        root.render(VProvider(TranslatorContext, t, listOf(content), null))
        syncMetrics()
    }

    /** Handles a chat [ClickEvent] (from [text]) like vanilla screens: links ask for confirmation, commands run … */
    internal fun handleClickEvent(event: ClickEvent) = defaultHandleGameClickEvent(event, minecraft, this)

    override fun extractBackground(ctx: GuiGraphicsExtractor, mouseX: Int, mouseY: Int, delta: Float) {
        if (vanillaBackground) super.extractBackground(ctx, mouseX, mouseY, delta)
    }

    /** Skipped when the document turns the blur off (`useBackgroundBlur(false)`); the dark overlay is drawn anyway. */
    override fun extractBlurredBackground(ctx: GuiGraphicsExtractor) {
        if (root.document.backgroundBlur) super.extractBlurredBackground(ctx)
    }

    // ---- own GUI scale ----------------------------------------------------------------------------------------
    // With `document.scale` set, the document lives in its own coordinate space: one CSS px = `scale` physical pixels.
    // It is drawn under an extra pose scale (scale / Minecraft's), mouse positions are divided by the same factor, and
    // text and SVGs are rasterized for the new pixel size (FontManager.activeScale).

    private val mcScale get() = minecraft.window.guiScale.toFloat().coerceAtLeast(1f)

    /** Physical pixels per CSS px for this screen. */
    private fun scale(): Float = root.document.scale?.coerceIn(0.25f, 16f) ?: mcScale

    /** Factor from this document's px to Minecraft's GUI px. */
    private fun factor(): Float = scale() / mcScale

    private inline fun <T> scaled(block: () -> T): T {
        val own = root.document.scale ?: return block()
        val before = FontManager.activeScale
        FontManager.activeScale = own.coerceIn(0.25f, 16f)
        try {
            return block()
        } finally {
            FontManager.activeScale = before
        }
    }

    private fun docX(x: Double) = (x / factor()).toFloat()
    private fun docY(y: Double) = (y / factor()).toFloat()

    override fun extractRenderState(ctx: GuiGraphicsExtractor, mouseX: Int, mouseY: Int, delta: Float) {
        val s = scale()
        root.document.resolution = s
        if (mounted && Translator.current() !== translator) renderContent()
        scaled {
            val t0 = System.nanoTime()
            if (root.document.scale == null) {
                val commands = root.frame(width.toFloat(), height.toFloat())
                val t1 = System.nanoTime()
                CommandRenderer.draw(ctx, commands, mouseX, mouseY)
                FrameStats.frame(t1 - t0, System.nanoTime() - t1)
            } else {
                val k = s / mcScale
                val commands = root.frame(minecraft.window.width / s, minecraft.window.height / s)
                val t1 = System.nanoTime()
                val pose = ctx.pose()
                pose.pushMatrix()
                pose.scale(k, k)
                CommandRenderer.draw(ctx, commands, (mouseX / k).toInt(), (mouseY / k).toInt())
                pose.popMatrix()
                FrameStats.frame(t1 - t0, System.nanoTime() - t1)
            }
        }
        metricsRoot?.let { m ->
            FrameStats.uncounted {
                m.document.resolution = mcScale
                CommandRenderer.draw(ctx, m.frame(width.toFloat(), height.toFloat()), mouseX, mouseY)
            }
        }
        val cursorOwner = metricsRoot?.takeIf { metricsPressed || onMetrics(mouseX.toDouble(), mouseY.toDouble()) } ?: root
        Cursors.of(cursorOwner.input.cursor)?.let(ctx::requestCursor)
        hoverTooltip(ctx, mouseX, mouseY)
        syncTextInput()
    }

    //#if MC >= 26.3
    //$$ private var textInput = false
    //$$ private var textInputArea: List<Int>? = null
    //#endif

    /**
     * From 26.3 on (SDL) Minecraft only receives typed characters while text input is switched on, which vanilla does
     * for a focused `EditBox`. GuiLib delivers characters to whatever element has focus (like GLFW did before), so text
     * input is on while any element is focused; the IME window is placed at that element.
     */
    private fun syncTextInput() {
        //#if MC >= 26.3
        //$$ val focused = root.document.focusedElement?.takeIf { mounted }
        //$$ if (focused == null) {
        //$$     if (textInput) minecraft.onTextInputFocusChange(this, false)
        //$$     textInput = false
        //$$     return
        //$$ }
        //$$ if (!textInput) minecraft.onTextInputFocusChange(this, true)
        //$$ textInput = true
        //$$ val r = focused.getBoundingClientRect()
        //$$ val f = factor()
        //$$ val area = listOf((r.x * f).toInt(), (r.y * f).toInt(), (r.width * f).toInt(), (r.height * f).toInt())
        //$$ if (area != textInputArea) {
        //$$     textInputArea = area
        //$$     minecraft.textInputManager().setTextInputArea(area[0], area[1], area[2], area[3])
        //$$ }
        //#endif
    }

    /**
     * Item / entity tooltips of hovered chat text ([text]) and of `item(…, tooltip = true)` icons, drawn by Minecraft
     * on top of everything like in chat and inventories.
     */
    private fun hoverTooltip(ctx: GuiGraphicsExtractor, mouseX: Int, mouseY: Int) {
        (root.input.hoveredItemTooltip() as? ItemStack)?.takeUnless { it.isEmpty }?.let {
            ctx.setTooltipForNextFrame(font, it, mouseX, mouseY)
            return
        }
        when (val hover = root.input.hoveredAttribute(MC_HOVER_ATTR)) {
            is HoverEvent.ShowItem -> ctx.setTooltipForNextFrame(font, hover.item().create(), mouseX, mouseY)
            is HoverEvent.ShowEntity -> if (minecraft.options.advancedItemTooltips) {
                ctx.setComponentTooltipForNextFrame(font, hover.entity().getTooltipLines(), mouseX, mouseY)
            }
        }
    }

    // Input handlers may measure text (caret placement), so they run with the screen's scale active too.

    override fun mouseMoved(x: Double, y: Double) {
        metricsRoot?.let { m -> FrameStats.uncounted { m.input.mouseMove(x.toFloat(), y.toFloat()) } }
        scaled { root.input.mouseMove(docX(x), docY(y)) }
    }

    override fun mouseClicked(click: MouseButtonEvent, doubled: Boolean): Boolean {
        val m = metricsRoot
        if (m != null && onMetrics(click.x(), click.y())) {
            metricsPressed = true
            return FrameStats.uncounted { m.input.mouseDown(click.x().toFloat(), click.y().toFloat(), Keys.domButton(click.button()), Keys.modifiers(click.modifiers())) }
        }
        return scaled {
            root.input.mouseDown(docX(click.x()), docY(click.y()), Keys.domButton(click.button()), Keys.modifiers(click.modifiers()))
        }
    }

    override fun mouseReleased(click: MouseButtonEvent): Boolean {
        val m = metricsRoot
        if (m != null && metricsPressed) {
            metricsPressed = false
            return FrameStats.uncounted { m.input.mouseUp(click.x().toFloat(), click.y().toFloat(), Keys.domButton(click.button()), Keys.modifiers(click.modifiers())) }
        }
        return scaled {
            root.input.mouseUp(docX(click.x()), docY(click.y()), Keys.domButton(click.button()), Keys.modifiers(click.modifiers()))
        }
    }

    override fun mouseDragged(click: MouseButtonEvent, deltaX: Double, deltaY: Double): Boolean {
        val m = metricsRoot
        if (m != null && metricsPressed) {
            // A drag that started on the metrics overlay (moving its window) belongs to it alone.
            FrameStats.uncounted { m.input.mouseMove(click.x().toFloat(), click.y().toFloat(), Keys.modifiers(click.modifiers())) }
            return true
        }
        return scaled {
            root.input.mouseMove(docX(click.x()), docY(click.y()), Keys.modifiers(click.modifiers()))
            true
        }
    }

    override fun mouseScrolled(mouseX: Double, mouseY: Double, horizontal: Double, vertical: Double): Boolean {
        val m = metricsRoot
        if (m != null && onMetrics(mouseX, mouseY)) {
            return FrameStats.uncounted {
                m.input.wheel(mouseX.toFloat(), mouseY.toFloat(), (-horizontal * SCROLL_STEP).toFloat(), (-vertical * SCROLL_STEP).toFloat(), Keys.currentModifiers())
            }
        }
        return scrollDocument(mouseX, mouseY, horizontal, vertical)
    }

    private fun scrollDocument(mouseX: Double, mouseY: Double, horizontal: Double, vertical: Double): Boolean = scaled {
        root.input.wheel(
            docX(mouseX), docY(mouseY), (-horizontal * SCROLL_STEP).toFloat(), (-vertical * SCROLL_STEP).toFloat(),
            Keys.currentModifiers(), // Minecraft passes no modifiers with the wheel; Shift + wheel scrolls sideways
        )
    }

    override fun keyPressed(keyInput: KeyEvent): Boolean {
        val mods = Keys.modifiers(keyInput.modifiers())
        val key = Keys.keyName(keyInput, mods)
        if (METRICS_SHORTCUT && key == "F12" && mods.ctrl && !mods.alt) {
            showMetrics = !showMetrics
            return true
        }
        if (scaled { root.input.keyDown(key, keyInput.key(), mods) }) return true
        return super.keyPressed(keyInput) // Escape closes the screen
    }

    override fun keyReleased(keyInput: KeyEvent): Boolean = scaled {
        val mods = Keys.modifiers(keyInput.modifiers())
        root.input.keyUp(Keys.keyName(keyInput, mods), keyInput.key(), mods)
    }

    override fun charTyped(input: CharacterEvent): Boolean = scaled { root.input.charTyped(input.codepointAsString()) }

    override fun isPauseScreen() = pauseGame

    override fun removed() {
        root.document.unmount()
        mounted = false
        syncMetrics()
        syncTextInput()
        Stylesheets.unwatch(this)
        super.removed()
    }

    companion object {
        /** Ctrl + F12 toggles the metrics overlay in every GuiLib screen; set to `false` to turn the shortcut off. */
        @JvmStatic var METRICS_SHORTCUT = true

        /** Pixels scrolled per mouse wheel notch. */
        var SCROLL_STEP = 20.0
    }
}
